import './App.css';
import { Sidebar, Menu, MenuItem, SubMenu } from 'react-pro-sidebar';
import { Routes, Route, Outlet, Link, useSearchParams, useNavigate, Router, BrowserRouter } from "react-router-dom";


function Layout() {
    return (
        <div>
            b
        </div>
    );
}

function MySidebar() {
    return (
        <Sidebar>
            <Menu>
                <MenuItem routerLink={<Link to="/" />}> Home</MenuItem>
                <MenuItem routerLink={<Link to="/search" />}> Search</MenuItem>
            </Menu>
        </Sidebar>
    )
}

function Title() {
    return (
        <header class="app-header">
            <nav class="bg-dark navbar-dark navbar">
                <div className="row col-12 d-flex justify-content-center text-white">
                    <h3>My App Page</h3>
                </div>
            </nav>
        </header>

    )
}

function Home() {
    return (
        <div>
            Home
        </div>
    );
}

function NoMatch() {
    return (
        {/* ... */ }
    );
}

function Search() {
    const [searchParams, setSearchParams] = useSearchParams();
    const navigate = useNavigate();
    let target = searchParams.get("term");
    const handleSubmit = (event) => {
        navigate('/search')
    };

    return (
        <div>
            <h2>Your search term: {target}</h2>
            <form onSubmit={handleSubmit}>
                <input type="text" id="mytext">
                </input>
            </form>
            <button onClick={() => {
                setSearchParams({ term: document.getElementById("mytext").value });
            }}>ok</button>
        </div>
    );
}

function App() {
    return (
        <div className="App">
            <Title />
            <MySidebar />
            <Routes>

                <Route >
                    <Route path="" element={<Home />} />
                    <Route path="search" element={<Search />} />
                </Route>
            </Routes>
        </div>
    );
}
export default App;