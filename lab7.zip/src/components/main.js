import React from 'react';
function Main() {
    return (

        <h3>Main</h3>

    );

}
export default Main;