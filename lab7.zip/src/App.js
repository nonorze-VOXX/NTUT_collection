import logo from './logo.svg';
import './App.css';

import Main from './components/main';
import Layout from './components/Mysidebar';

function App() {
  return (
    <div className="App">
      <Layout />
      <Main />

    </div>
  );
}


export default App;
